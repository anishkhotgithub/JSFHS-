package com.niit.springfrontend;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.niit.daoimpl.UserDAOImpl;
import com.niit.model.User;

@Controller
@RequestMapping(value="/user")
public class UserController
{
	@RequestMapping(value="/add")
	public String m1(ModelMap map)
	{
		map.addAttribute("user",new User());
		return "adduser";
	}
	
	@RequestMapping(value="/adduser")
	public String m2(@ModelAttribute("user") User u)
	{
		UserDAOImpl udi=new UserDAOImpl();
		udi.addUser(u);
		return "redirect:/user/display";
	}
	
	@RequestMapping(value="/display")
	public String m3(ModelMap map)
	{
		UserDAOImpl udi=new UserDAOImpl();
		map.addAttribute("usrs",udi.displayUser());
		return "users";
	}
	
	@RequestMapping(value="/delete/{uid}")
	public String m4(@PathVariable("uid") int userid)
	{
		User u=new User();
		u.setUserid(userid);
		UserDAOImpl udi=new UserDAOImpl();
		udi.deleteUser(u);
		return "redirect:/user/display";
	}
	
}
